import React, { Component } from 'react';
import '../newTask/NewTask.css'
import { BrowserRouter as Router, Route, Link } from "react-router-dom";

//class Try4 extends Component {
  const Try4 = ({ my }) => <h1>{my}</h1>;

  
  //render() {
    //return (
     // <div>
//<div>{this.props.my}</div>

    //  </div>
   // );
 // }
//}

export default Try4;
